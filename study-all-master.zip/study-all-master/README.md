# knowledge

# 比较好玩的东西

[适合做页面背景动效的js](http://paperjs.org/)