# 网站 - 软件
[ZCJUN](https://zcjun.com/) \
[花间社](https://www.huajclub.com/) \
[小众软件](https://www.appinn.com/) \
[全平台软件](https://wiki.winehq.org/Download_zhcn) \
[万彩办公大师](http://www.wofficebox.com/) \
[关机重启](https://github.com/lukaslangrock/ShutdownTimerClassic) \
# 网站 - 工具
[在线工具](https://tool.lu/) \
[在线工具](https://www.lmcjl.com/) \
[在线工具](https://www.wdku.net/) \
[在线工具](https://www.zxgj.cn/) \
[在线工具](http://tools.bugscaner.com/) \
[在线工具](https://www.bejson.com/) \
[Qtool在线](https://www.qtool.net/) \
[PHP中文网](https://www.php.cn/xiazai/tool) \
[爱资料在线](https://www.toolnb.com/) \
[菜鸟工具](https://c.runoob.com/) \
[蛙蛙工具](https://www.iamwawa.cn/) \
[兔二工具](https://www.tool22.com/) \
[MikuTools](https://tools.miku.ac/) \
[PDF转换](https://smallpdf.com/) \
[草料二维码](https://cli.im/) \
[二维码助手](https://so.csdn.net/plugin/qrcode.html?query=https://csdn.net&spm=1000.2115.3001.5851) \
[JSON格式化](https://www.json.cn/) \
[JSON工具](https://so.csdn.net/plugin/jsonPages.html?spm=1000.2115.3001.5850) \
[在线思维导图](https://miyuesc.github.io/process-designer/) \
[在线思维导图](https://miyuesc.gitee.io/process-designer/) \
[在线代码编辑器](https://jojowwbb.github.io/pen/index.html) \
[小闪电（在线代码）](https://jsrun.net/) \
[一个木函（手机APP）](http://www.woobx.cn/index.html) \
# 网站 - 素材
[花瓣](https://huaban.com/) \
[图怪兽](https://818ps.com/) \
[多元文化头像生成器](https://multiavatar.com/) \
