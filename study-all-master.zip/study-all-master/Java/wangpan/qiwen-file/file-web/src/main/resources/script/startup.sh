#!/bin/bash

BUILD_ID=dontKillMe

nohup java -jar app/file-web/file-web-1.0.0-SNAPSHOT.jar --server.port=8763 &



