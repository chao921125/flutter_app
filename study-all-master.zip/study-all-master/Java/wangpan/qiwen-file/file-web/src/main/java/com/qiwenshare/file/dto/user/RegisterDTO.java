package com.qiwenshare.file.dto.user;


public class RegisterDTO {

}
